import staticAnalyzer
import sys

staticAnalyzer.run(sys.argv[1], sys.argv[2])
